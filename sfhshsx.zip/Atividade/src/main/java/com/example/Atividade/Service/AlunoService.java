package com.example.Atividade.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.Atividade.model.AlunoModel;

@Service
public class AlunoService {
  
	 public  List<AlunoModel> alunos(){
		 List<AlunoModel> list =new ArrayList<AlunoModel>();
		 AlunoModel aluno1;
		 
		 aluno1= new AlunoModel();
		 aluno1.setMatricula("10");
		 aluno1.setNome("Maria");
		 list.add(aluno1);
		
		 aluno1= new AlunoModel();
		 aluno1.setMatricula("1");
		 aluno1.setNome("Jose");
		 list.add(aluno1);

		 return list;
		 
	 }
	 
	   public String obterAluno(String matricula) {
		   for (AlunoModel aluno: alunos()) {
			   if (matricula.equals(aluno.getMatricula()))
				   return aluno.getNome();
		   }
		   return null;
		   
	   }
	   
	   public String obterPorNome(String nome) {
		   for (AlunoModel aluno: alunos()) {
			   if (nome.equals(aluno.getNome()))
				   return aluno.getMatricula();
		   }
		   return null;
		   
	   }

	
}
