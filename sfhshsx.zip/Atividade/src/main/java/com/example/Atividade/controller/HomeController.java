package com.example.Atividade.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Atividade.Service.AlunoService;
import com.example.Atividade.model.AlunoModel;

@RestController
@RequestMapping("/aluno")
public class HomeController {


	@Autowired
	private AlunoService service;


	@GetMapping
	public String saudacao() {
		return "Você esta em uma aplicação de conhecimento em MicroServiços"
				+ "";	
	}


	@GetMapping("/todos")
	public List<AlunoModel> alunos(){
		return service.alunos();

	}
	
	@GetMapping("/Id/{matricula}")
	public String  nomealuno (@PathVariable String matricula) {
		return service.obterAluno(matricula);
	}
	
	@GetMapping("/Nome/{nome}")
	public String  matriculaAluno (@PathVariable String nome) {
		return service.obterPorNome(nome);
	}
	
	

}
