package com.example.Atividade.model;

public class AlunoModel {
   
	private String matricula;
	private String nome;
	
	
	public AlunoModel(String matricula, String nome) {
		super();
		this.matricula = matricula;
		this.nome = nome;
	}
	
	
	public AlunoModel() {
		
	}


	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	
}
